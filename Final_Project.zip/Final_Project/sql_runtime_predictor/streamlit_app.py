import streamlit as st
import pandas as pd
import joblib
import sqlparse
import numpy as np
import os

def analyze_sql(sql_text):
    sql_text = sqlparse.format(sql_text, reindent=True, keyword_case="lower")
    parsed = sqlparse.parse(sql_text)[0]
    tokens = [str(tok).lower() for tok in parsed.flatten()]

    keywords = ["select", "join", "where", "group by", "order by", "having"]
    counts   = {k: 0 for k in keywords}

    for token in tokens:
        for k in keywords:
            if k in token:
                counts[k] += 1
    return counts

reg_model_path = "models/regression_model.joblib"
clf_model_path = "models/classification_model.joblib"

reg = joblib.load(reg_model_path)
clf = joblib.load(clf_model_path)

st.title("🧠 SQL Query Runtime Predictor")
st.markdown("Paste your SQL query below to predict estimated runtime (seconds) and performance class (Fast / Moderate / Slow).")

sql_input = st.text_area("Your SQL Query:", height=200)

if st.button("Predict Runtime"):
    if sql_input.strip() == "":
        st.warning("Please enter a SQL query first.")
    else:
        
        features_dict = analyze_sql(sql_input)
        st.subheader("Extracted SQL Features")
        st.write(pd.DataFrame([features_dict]))


        
        X_new = pd.DataFrame([features_dict])
        pred_time  = reg.predict(X_new)[0]
        pred_class = clf.predict(X_new)[0]


        
        st.subheader("Prediction")
        st.write(f"⏱️  Estimated Runtime: **{pred_time:.2f} seconds**")
        st.write(f"⚡  Predicted Class: **{pred_class}**")
        st.success("Prediction completed!")


        
        image_path = "output/streamlit_demo.png"
        if os.path.exists(image_path):
            st.image(image_path, caption="Sample Output Image", use_column_width=True)
