import streamlit as st
import pandas as pd
import joblib
import sqlparse

# 分析 SQL 的函数
def analyze_sql(sql_text):
    sql = sqlparse.format(sql_text, reindent=True, keyword_case='lower')
    parsed = sqlparse.parse(sql)[0]
    tokens = [str(t).lower() for t in parsed.flatten()]
    
    keywords = ['select', 'join', 'where', 'group by', 'order by', 'having']
    counts = {k: 0 for k in keywords}
    
    for token in tokens:
        for k in keywords:
            if k in token:
                counts[k] += 1
    return counts

# 加载模型
reg = joblib.load('output/sql_runtime_regressor.pkl')
clf = joblib.load('output/sql_runtime_classifier.pkl')

st.title("🧠 SQL Query Runtime Predictor")
st.markdown("Paste your SQL query below to predict estimated runtime and performance class.")

sql_input = st.text_area("Your SQL Query:", height=200)

if st.button("Predict Runtime"):
    if sql_input.strip() == "":
        st.warning("Please enter a SQL query first.")
    else:
        features = analyze_sql(sql_input)
        st.subheader("Extracted SQL Features")
        st.write(pd.DataFrame([features]))

        X_new = pd.DataFrame([features])
        pred_time = reg.predict(X_new)[0]
        pred_class = clf.predict(X_new)[0]

        st.subheader("Prediction")
        st.write(f"⏱️ **Estimated Runtime:** `{round(pred_time, 2)} ms`")
        st.write(f"⚡ **Predicted Class:** `{pred_class}`")

        st.success("Prediction completed!")
